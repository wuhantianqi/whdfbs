<?php
/**
 * Copy Right IJH.CC$
 * $Id index.php by @shzhrui$
 */
require(dirname(dirname(__FILE__))."/system/admin/index.php");
new Index();